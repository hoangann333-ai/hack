# Thư viện giải phương trình bậc hai

Thư viện Java thuần, không cần thư viện ngoài. Lớp chính: `com.codegym.math.QuadraticEquationSolver`.

## Đóng gói thành file JAR

Cần cài JDK 8 trở lên và Maven. Mở terminal tại thư mục `quadratic-equation-library`, chạy:

```bash
mvn clean package
```

File thư viện được tạo tại:

```text
target/quadratic-equation-library-1.0.0.jar
```

Để cài thư viện vào Maven local repository cho dự án khác dùng:

```bash
mvn install
```

Sau đó thêm vào `pom.xml` của dự án sử dụng:

```xml
<dependency>
    <groupId>com.codegym</groupId>
    <artifactId>quadratic-equation-library</artifactId>
    <version>1.0.0</version>
</dependency>
```

## Cách gọi thư viện

```java
import com.codegym.math.QuadraticEquationSolver;

QuadraticEquationSolver.Result result =
        QuadraticEquationSolver.solve(1, -3, 2);
System.out.println(result); // Hai nghiệm phân biệt: x1 = 1.0, x2 = 2.0
```

Chạy ví dụ `com.codegym.demo.LibraryDemo` để xem cách gọi API.

## Các trường hợp được xử lý

- `delta > 0`: hai nghiệm thực phân biệt, được trả theo thứ tự tăng dần.
- `delta = 0`: nghiệm kép.
- `delta < 0`: không có nghiệm thực.
- `a = 0`: xử lý tiếp phương trình bậc nhất/phương trình hằng.
- Hệ số `NaN` hoặc vô cực: ném `IllegalArgumentException`.

## Cấu trúc

- `src/main/java/com/codegym/math/QuadraticEquationSolver.java`: API thư viện.
- `src/main/java/com/codegym/demo/LibraryDemo.java`: ví dụ sử dụng.
- `pom.xml`: cấu hình Maven đóng gói JAR.
