package com.codegym.demo;

import com.codegym.math.QuadraticEquationSolver;

/** Small example demonstrating how a consumer calls the library API. */
public class LibraryDemo {
    public static void main(String[] args) {
        QuadraticEquationSolver.Result result = QuadraticEquationSolver.solve(1, -3, 2);
        System.out.println(result);
        System.out.println("Loại kết quả: " + result.getType());
        System.out.println("Delta: " + result.getDiscriminant());
    }
}
