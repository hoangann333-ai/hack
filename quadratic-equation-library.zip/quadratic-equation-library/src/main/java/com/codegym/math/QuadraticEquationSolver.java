package com.codegym.math;

/**
 * Library for solving equations of the form ax^2 + bx + c = 0.
 * The class has no external dependencies and can be reused from other Java projects.
 */
public final class QuadraticEquationSolver {
    private QuadraticEquationSolver() {
    }

    /**
     * Solves ax^2 + bx + c = 0 over the real numbers.
     * If a is zero, the equation is treated as a linear or constant equation.
     *
     * @throws IllegalArgumentException if any coefficient is NaN or infinite
     */
    public static Result solve(double a, double b, double c) {
        if (!isFinite(a) || !isFinite(b) || !isFinite(c)) {
            throw new IllegalArgumentException("Các hệ số phải là số hữu hạn.");
        }

        if (a == 0.0d) {
            if (b != 0.0d) {
                return Result.linear(-c / b);
            }
            return c == 0.0d ? Result.infiniteSolutions() : Result.noSolution();
        }

        double delta = b * b - 4.0d * a * c;
        if (delta < 0.0d) {
            return Result.noRealRoots(delta);
        }
        if (delta == 0.0d) {
            return Result.doubleRoot(-b / (2.0d * a), delta);
        }

        double sqrtDelta = Math.sqrt(delta);
        double x1 = (-b - sqrtDelta) / (2.0d * a);
        double x2 = (-b + sqrtDelta) / (2.0d * a);
        if (x1 <= x2) {
            return Result.twoRoots(x1, x2, delta);
        }
        return Result.twoRoots(x2, x1, delta);
    }

    private static boolean isFinite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    public enum Type {
        TWO_REAL_ROOTS,
        DOUBLE_ROOT,
        NO_REAL_ROOTS,
        LINEAR_EQUATION,
        INFINITE_SOLUTIONS,
        NO_SOLUTION
    }

    /** Immutable value object containing the solution type and roots. */
    public static final class Result {
        private final Type type;
        private final double root1;
        private final double root2;
        private final double discriminant;

        private Result(Type type, double root1, double root2, double discriminant) {
            this.type = type;
            this.root1 = root1;
            this.root2 = root2;
            this.discriminant = discriminant;
        }

        private static Result twoRoots(double x1, double x2, double delta) {
            return new Result(Type.TWO_REAL_ROOTS, x1, x2, delta);
        }
        private static Result doubleRoot(double x, double delta) {
            return new Result(Type.DOUBLE_ROOT, x, x, delta);
        }
        private static Result noRealRoots(double delta) {
            return new Result(Type.NO_REAL_ROOTS, Double.NaN, Double.NaN, delta);
        }
        private static Result linear(double x) {
            return new Result(Type.LINEAR_EQUATION, x, Double.NaN, Double.NaN);
        }
        private static Result infiniteSolutions() {
            return new Result(Type.INFINITE_SOLUTIONS, Double.NaN, Double.NaN, Double.NaN);
        }
        private static Result noSolution() {
            return new Result(Type.NO_SOLUTION, Double.NaN, Double.NaN, Double.NaN);
        }

        public Type getType() { return type; }
        public double getRoot1() { return root1; }
        public double getRoot2() { return root2; }
        public double getDiscriminant() { return discriminant; }
        public boolean hasRealRoots() {
            return type == Type.TWO_REAL_ROOTS || type == Type.DOUBLE_ROOT || type == Type.LINEAR_EQUATION;
        }

        @Override
        public String toString() {
            switch (type) {
                case TWO_REAL_ROOTS:
                    return "Hai nghiệm phân biệt: x1 = " + root1 + ", x2 = " + root2;
                case DOUBLE_ROOT:
                    return "Nghiệm kép: x = " + root1;
                case NO_REAL_ROOTS:
                    return "Phương trình vô nghiệm trong tập số thực.";
                case LINEAR_EQUATION:
                    return "Phương trình trở thành bậc nhất, nghiệm x = " + root1;
                case INFINITE_SOLUTIONS:
                    return "Phương trình có vô số nghiệm.";
                default:
                    return "Phương trình vô nghiệm.";
            }
        }
    }
}
